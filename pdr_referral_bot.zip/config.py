
BOT_TOKEN = "8043359242:AAEia9gtXRcWvkAHwEzMPKjz_OFvvY8ogdw"
MASTER_ID = 1116404296  # @pdrgarage_by Telegram ID
